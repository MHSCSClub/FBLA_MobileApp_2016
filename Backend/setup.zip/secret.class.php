<?php
	/*
		Secret class
		Database credentials stored
	*/
	class Secret
	{
		public static $username = "username";
		public static $password = "password";
	}
	
?>